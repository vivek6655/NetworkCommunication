package NetworkCommunication;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;
import java.util.Collections;

import javax.net.ssl.HttpsURLConnection;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;

import org.json.simple.JSONObject;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;



public class SocketCommunication {

	public JSONObject getSocketJSONResponse(String callName) {
	Socket socket = null;
	ObjectOutputStream oos = null;
	ObjectInputStream ois = null;
	JSONObject jsonRequest = null;
	JSONObject jsonResponse = null;
	String serverIP = "", serverPort = "";
	serverIP = GetJSON.prop.getProperty("SocketServerIP");
	serverPort = GetJSON.prop.getProperty("SocketServerPort");
	try {
		socket = new Socket(serverIP, Integer.parseInt(serverPort));
		oos = new ObjectOutputStream(socket.getOutputStream());
		ois = null; 
		jsonRequest = new JSONObject();
		jsonRequest.put("NewgenIntegrationCallName", callName);
		oos.writeObject(jsonRequest);
		ois = new ObjectInputStream(socket.getInputStream());
		jsonResponse = (JSONObject)ois.readObject(); 
	}catch(Exception e) {
		e.printStackTrace();
	}finally {
			try {
				if(socket!=null) {
					socket.close();
					socket = null;
				}
				if(oos != null) {
					oos.close();
					oos = null;
				}
				if(ois != null) {
					ois.close();
					ois = null;
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
	}
	return jsonResponse;
}


 public String getSocketXMLResponse(String xmlRequest) {
	Socket socket = null;
	ObjectOutputStream oos = null;
	ObjectInputStream ois = null;
	String xmlResponse = "";
	String serverIP = "", serverPort = "";
	String cabinetName = GetJSON.prop.getProperty("CABINET_NAME");
	serverIP = GetJSON.prop.getProperty("SocketServerIP");
	serverPort = GetJSON.prop.getProperty("SocketServerPort");
	//CAD.mLogger.info("SOCKET SERVER IP:PORT" + serverIP + ":" + serverPort);
	try {
		socket = new Socket(serverIP, Integer.parseInt(serverPort));
		oos = new ObjectOutputStream(socket.getOutputStream());
		ois = null; 
		//CAD.mLogger.info("SOCKET CONNECTOR : Request XML is: " + xmlRequest);
		oos.writeObject(xmlRequest);
		socket.setSoTimeout(Integer.parseInt(GetJSON.prop.getProperty("SocketConnectionTimeOut")));
		ois = new ObjectInputStream(socket.getInputStream());
		xmlResponse = (String)ois.readObject(); 
	}
	catch(SocketTimeoutException STE) {
		//CAD.mLogger.info("SOCKET CONNECTION TIMED OUT: " + STE.getMessage());
		xmlResponse= "<ERROR>SOCKET CONNECTION TIMED OUT</ERROR>";
		//CAD.mLogger.error(STE.toString());
	}
	catch(Exception e) {
	//	CAD.mLogger.info("Exception in connecting to socket");
		xmlResponse= "<ERROR>EXCEPTION OCCURED </ERROR>";
	//	CAD.mLogger.error(e.toString());
	}finally {
			try {
				if(socket!=null) { socket.close(); socket = null; }
				if(oos != null) { oos.close(); oos = null; }
				if(ois != null) { ois.close(); ois = null; }
			} catch (IOException e) {
				//CAD.mLogger.error(e.toString());
			}
	}
	//CAD.mLogger.info("SOCKET CONNECTOR : Response XML is: " + xmlResponse);
	return xmlResponse;
}


public static String callSoapWebservice(SOAPMessage Request, String url)
{
	//CAD.mLogger.info("Inside Call SOAP Web Service!!");
	//String req;
	//SOAPMessage r = SOAPMessage() req;
	String response;
	try
	{
		SOAPConnectionFactory scf = SOAPConnectionFactory.newInstance();
		SOAPConnection sc = scf.createConnection();
		response = sc.call(Request, url).toString();
		return response;
	}
	catch(Exception e)
	{
//		CAD.mLogger.error("Some error occured!");
//		CAD.mLogger.error(e.toString());
		return "FAIL";
	}
	//return response;
}


private String connectURLXML(String requestXML, String callName) {
	int ResponseCode = 0;
	String xmlResponse = "", inputLine="";
	try {
		String urlString = (String)GetJSON.prop.get(callName+"_URL");
        if(null == urlString || "".equalsIgnoreCase(urlString))
        {
          //  CAD.mLogger.error("EndpointURL NOT FOUND for call : " + callName);
            return "Exception";
        }

		//CAD.mLogger.info("urlString is: " + urlString);
        URL url = null;
        HttpsURLConnection s_conn = null;
        HttpURLConnection conn = null;
        if(urlString.contains("https"))
            url = new URL(urlString);
        else
            url = new URL(urlString);
        sCon = (HttpsURLConnection)url.openConnection();
      //  CAD.mLogger.info("url: "+ url);
        URLConnection connection = url.openConnection();
        conn = (HttpURLConnection)connection;
      //  CAD.mLogger.info("conn : "+conn);
        //url.openConnection();
        conn.setRequestProperty("Content-Type", "text/xml");
        int connectionTimeOut = 30000;
        int readTimeOut = 30000;
        try
        {
        	//connectionTimeOut = Integer.parseInt((String)GetJSON.prop.get("ConnectionTimeOut"));
        	connectionTimeOut =30000;
        	//readTimeOut = Integer.parseInt((String)GetJSON.prop.get("ReadTimeOut"));
        	readTimeOut = 30000;
        }
        catch(Exception e)
        {
        //	CAD.mLogger.info("Exception at setting connection Timeout");
        	return "Exception";
        }
        conn.setConnectTimeout(connectionTimeOut);
        conn.setReadTimeout(readTimeOut);
        String methodName = (String) GetJSON.prop.get(callName+"_Method");
        //String methodName = "POST";
     //   CAD.mLogger.info("methodName = " + methodName);
        conn.setRequestMethod(methodName);//Get or post
        byte[] postData = requestXML.getBytes();
        conn.setDoInput(true);
        conn.setDoOutput(true);
        OutputStream out = (OutputStream) conn.getOutputStream();
        out.write(postData);
        out.close();
        ResponseCode = conn.getResponseCode();
      //  CAD.mLogger.info("ResponseCode" + ResponseCode);
        InputStream inputStream = null;
        try
        {
        	inputStream = conn.getInputStream();
        }
        catch(Exception e)
        {
        //	CAD.mLogger.info("getting ErrorStream now");
        	inputStream = conn.getErrorStream();
        //	CAD.mLogger.info("Got Error Stream : "+inputStream); 
        	return "Exception";
        }
        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
        StringBuffer content = new StringBuffer();
        while ((inputLine = reader.readLine()) != null)
        {
            content.append(inputLine);
        }
        reader.close();
    //    CAD.mLogger.info("Parsing respnse:");
        xmlResponse = content.toString();
        if(ResponseCode == 200)
        {
        	 xmlResponse = content.toString();
        }
    //    CAD.mLogger.info("completed");
	}
	catch(Exception e)
	{
	//	CAD.mLogger.info("Exception Occured in CONNECTURLXML..Response Code is: " + ResponseCode);
		return "Exception";
	}
	return xmlResponse;
}
	public static void main(String[] args) {
		

	}
	
	
	public static String postXmlToUrl(String inputXml, String apiUrl) {
		
		String response = "";
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.valueOf("application/xml"));
			headers.setAccept(Collections.singletonList(MediaType.APPLICATION_XML));

			RestTemplate restTemplate = new RestTemplate();
			HttpEntity<String> requestEntity = new HttpEntity<String>(inputXml, headers);

			ResponseEntity<String> responseEntity = restTemplate.exchange(apiUrl, HttpMethod.POST, requestEntity,
					String.class);
			response = responseEntity.getBody();
			response = response.replaceAll("&lt;", "<");
			response = response.replaceAll("&gt;", ">");
        	//logger.info("output-->postXmlToUrl-->"+response);
		} catch (Exception e) {
	//		logger.error("exception is occuring to connect with server");
			e.printStackTrace();

		}
		return response;
	}
	

}
