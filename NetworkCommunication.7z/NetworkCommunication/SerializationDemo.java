package NetworkCommunication;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class SerializationDemo {

	public static void main(String[] args) throws IOException {
	
		Student s1=new Student(101,"vivek");
		
		// serialization
		FileOutputStream fout=new FileOutputStream("abc.txt");
		ObjectOutputStream out=new ObjectOutputStream(fout);
		out.writeObject(s1);
		 out.flush();    
		 out.close(); 
		 System.out.println("success"); 
		 
		 
	}

}
