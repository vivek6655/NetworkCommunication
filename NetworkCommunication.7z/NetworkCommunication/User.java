package NetworkCommunication;

public class User extends Person{

	String course;    
	int fee; 
	 
	 public User(int id, String name, String course, int fee) {    
		  super(id,name);    
		  this.course=course;    
		  this.fee=fee;    
		 }

	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}

	public int getFee() {
		return fee;
	}

	public void setFee(int fee) {
		this.fee = fee;
	}   

	 
}
