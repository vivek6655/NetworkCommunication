package NetworkCommunication;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

public class MyServer1 {

	public static void main(String[] args) throws IOException {
		
		ServerSocket serverSocket=new ServerSocket(3333);
		Socket socket=serverSocket.accept();
		
		DataInputStream din=new DataInputStream(socket.getInputStream());
		DataOutputStream dout=new DataOutputStream(socket.getOutputStream());
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in)); 
		
		String str="",str2=""; 
		
		while(!str.equals("stop")){  
			str=din.readUTF();  
			System.out.println("client says: "+str); 
			System.out.println("please give response...");
			str2=br.readLine();  
			dout.writeUTF(str2);  
			dout.flush();  
			}  
		
		din.close();  
		socket.close();  
		serverSocket.close(); 
	}

}
