package NetworkCommunication;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class SerializeISA {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		
		User s1 =new User(211,"ravi","Engineering",50000);  
		FileOutputStream fout=new FileOutputStream("f.txt");
		ObjectOutputStream os=new ObjectOutputStream(fout);
		os.writeObject(os);
		os.flush();
		os.close();
		System.out.println("success");
		
		///////////////////
		FileInputStream fin=new FileInputStream("f.txt");
		ObjectInputStream on=new ObjectInputStream(fin);
		User user=(User) on.readObject();
		System.out.println(user.getId()+" "+user.getName()+" "+user.getCourse()+" "+user.getFee());
		on.close();

	}

}
