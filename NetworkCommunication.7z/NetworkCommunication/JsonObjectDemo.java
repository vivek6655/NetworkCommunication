package NetworkCommunication;

public class JsonObjectDemo {
	
	String name;
	int age;

}
