package NetworkCommunication;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

public class UrlConnectionDemo {

	public static void main(String[] args) throws IOException {
	

/*
    we used UrlConnectionDemo to read and write data to the
    specified resource referred by the URL. 
*/
		URL url=new URL("http://localhost:8080/datas");
		//URL url=new URL("http://www.javatpoint.com/java-tutorial");
		
//		URLConnection urlcon=url.openConnection();
//		InputStream stream=urlcon.getInputStream(); 
//		int i;    
//		while((i=stream.read())!=-1){    
//		System.out.print((char)i);    
//		}   
		
		/*
		 * By the help of HttpURLConnection class,
		 *  you can retrieve information of any
		 *  HTTP URL such as header information, status code, response code etc.
		 */
		
		//URL url=new URL("http://www.javatpoint.com/java-tutorial");    
		HttpURLConnection huc=(HttpURLConnection)url.openConnection(); 
		StringBuilder response = new StringBuilder();
		BufferedReader reader = new BufferedReader(new InputStreamReader(huc.getInputStream()));
		 String line;
         while ((line = reader.readLine()) != null) {
              response.append(line);
         }
		
//		System.out.println("ResponseCode :"+huc.getResponseCode());
//		System.out.println("Requested Method :"+ huc.getRequestMethod());
//		System.out.println("ResponseMessage :"+huc.getResponseMessage());
//		for(int i=1;i<=8;i++){  
//		System.out.println(huc.getHeaderFieldKey(i)+" = "+huc.getHeaderField(i));  
//		
//		}  
//		huc.disconnect(); 

	}

}
