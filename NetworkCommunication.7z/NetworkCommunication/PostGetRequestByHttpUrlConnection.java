package NetworkCommunication;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

public class PostGetRequestByHttpUrlConnection {

	public static String sendGetRequest(String url) throws IOException {
		
        HttpURLConnection connection = null;
        BufferedReader reader = null;
       // StringBuilder response = new StringBuilder();
        List response=new ArrayList();
        try {
            URL apiUrl = new URL(url);
            connection = (HttpURLConnection) apiUrl.openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setDoOutput(true);
            
//            try (OutputStream os = connection.getOutputStream()) {
//                byte[] input = jsonInput.toJSONString().getBytes("utf-8");
//                os.write(input, 0, input.length);
//            }

            reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));

            String line;
            while ((line = reader.readLine()) != null) {
            	
            	response.add(line);
              //  response.append(line);
            }
        } finally {
            if (reader != null) {
                reader.close();
            }
            if (connection != null) {
                connection.disconnect();
            }
        }

        return response.toString();
    }
	
	
	 public static String sendPostRequest(String url, JSONObject jsonInput) throws IOException {
	        HttpURLConnection connection = null;
	        BufferedReader reader = null;
	        StringBuilder response = new StringBuilder();

	        try {
	            URL apiUrl = new URL(url);
	            connection = (HttpURLConnection) apiUrl.openConnection();
	            connection.setRequestMethod("POST");
	            connection.setRequestProperty("Content-Type", "application/json");
	            connection.setDoOutput(true);

	            try (OutputStream os = connection.getOutputStream()) {
	                byte[] input = jsonInput.toJSONString().getBytes("utf-8");
	                os.write(input, 0, input.length);
	            }

	            reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));

	            String line;
	            while ((line = reader.readLine()) != null) {
	                response.append(line);
	            }
	        } finally {
	            if (reader != null) {
	                reader.close();
	            }
	            if (connection != null) {
	                connection.disconnect();
	            }
	        }

	        return response.toString();
	    }
	
	
	public static void main(String[] args) throws IOException {
		
		String jsonInput = "{\"name\":\"foo\"}";
    	JSONObject input  = (JSONObject)JSONValue.parse(jsonInput);
    	String response=sendGetRequest("http://localhost:8080/datas");
    	System.out.println(response);
    	String postResponse = sendPostRequest("http://localhost:8080/postTest", input);
        System.out.println("\nPOST Response:\n" + postResponse);

	}

}
