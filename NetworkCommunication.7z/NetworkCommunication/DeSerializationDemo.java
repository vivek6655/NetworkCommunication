package NetworkCommunication;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class DeSerializationDemo {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		
		FileInputStream fin=new FileInputStream("abc.txt");
		ObjectInputStream oin=new ObjectInputStream(fin);
		  Student s=(Student)oin.readObject();
		  System.out.println(s.getId()+" "+s.getName()); 
		  oin.close();  

	}

}
